const Koa = require("koa");
const cors = require("@koa/cors");

const app = new Koa();
app.use(cors());

app.use(async ctx => {
  ctx.body = Number(ctx.query.number1) + Number(ctx.query.number2);
});

app.listen(4000);
