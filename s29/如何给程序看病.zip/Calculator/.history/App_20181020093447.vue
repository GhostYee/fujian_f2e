<template>
    <div>yo</div>
</template>
<script>
import { Calculator } from "./Calculator";
export default {
    data() {
    return {
        calculator: new Calculator()
    }
},
method: {
    add() {
        this.calculator.add(1, 2);
    }
}
}
</script>
