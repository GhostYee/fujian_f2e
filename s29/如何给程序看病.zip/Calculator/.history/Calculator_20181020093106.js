class Calculator {
  add(a) {
    return a + b;
  }
}

export { Calculator };
