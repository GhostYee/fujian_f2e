class Calculator {
  add(a, b) {
    return a + b;
  }

  add2(a, b) {
    return a + b;
  }
}

export { Calculator };
