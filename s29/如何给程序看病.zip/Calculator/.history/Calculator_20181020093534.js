class Calculator {
  add(a, b) {
    throw new Error();
    a + b;
  }
}

export { Calculator };
