<template>
    <div>
        <input type="number" v-model.number="number1">
        +
        <input type="number" v-model.number="number2" >
        =
        <span>{{result}}</span>
        <br>
        <button v-on:click="calculate()">calculate()</button>

    <button></button>
    </div>
</template>

<style>
input {
  width: 20px;
}
</style>

<script>
import { Calculator } from "./Calculator";

export default {
    data() {
        return {
            number1: 1,
            number2: 2,
            result: null,
            calculator: new Calculator()
        }
    },
    methods: {
        calculate() {
            this.result = this.calculator.add(this.number1, this.number2);
        }
    }
}
</script>
