class Calculator {
  add(a, b) {
    return a + b;
  }
  add2(a, b) {
    return;
  }
}

export { Calculator };
