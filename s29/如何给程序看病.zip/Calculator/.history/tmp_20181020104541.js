function random(min, max) {
  const result = Math.floor(Math.random() * (max - min + 1)) + min;
  if (result === 1) {
    return NaN;
  }
  return result;
}

if (isNaN(random(1, 5))) {
  debugger;
}
