import { axios } from "axios";

class Calculator {
  add(number1, number2) {
    axios.get("/add", {
      number1,
      number2
    });
  }
}

export { Calculator };
