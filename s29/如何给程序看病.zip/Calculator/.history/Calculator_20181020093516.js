class Calculator {
  add(a, b) {
    a + b;
  }
}

export { Calculator };
