class Calculator {
  addd(a, b) {
    return a + b;
  }
}

export { Calculator };
