<template>
    <div>
        <input type="number" v-model.number="number1">
        +
        <input type="number" v-model.number="number2" >
        =
        <span>{{result}}</span>
        <br>
        <button v-on:click="calculateError()">calculateError()</button>
        <button v-on:click="calculate()">calculate()</button>
        <br>
        <br>
        <button v-on:click="random()">random()</button>
        <span>{{randomNumber}}</span>
    </div>
</template>

<style>
input {
  width: 20px;
}
</style>

<script>
import { Calculator } from "./Calculator";
console.log(123123213)

export default {
    data() {
        return {
            number1: 1,
            number2: 2,
            result: null,
            randomNumber: 1,
            calculator: new Calculator()
        }
    },
    methods: {
        calculate() {
            this.result = this.calculator.add(this.number1, this.number2);
            
        },
        calculateError() {
            this.result = this.calculator.addd(this.number1, this.number2);
            
        },
        random() {
            this.randomNumber = this.calculator.random(1, 5);
            
        }
    }
}
</script>
