class Calculator {
  add(a, b) {
    return a + b;
  }
}

export { Calculator };
