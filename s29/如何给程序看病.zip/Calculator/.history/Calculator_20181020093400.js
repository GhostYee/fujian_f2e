class Calculator {
  add(a, b) {
    return a * b;
  }
  add(a, b) {
    return a + b + c;
  }
}

export { Calculator };
