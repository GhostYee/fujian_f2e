<template>
    <div>yo</div>
</template>
<script>
export default {
    
}
</script>
