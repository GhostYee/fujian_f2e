class Calculator {
  addd(a, b) {
    a + b;
  }
}

export { Calculator };
