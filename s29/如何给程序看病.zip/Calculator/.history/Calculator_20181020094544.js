class Calculator {
  add(a, b) {
    return a + b;
  }

  add(a) {
    return a + b;
  }
}

export { Calculator };
