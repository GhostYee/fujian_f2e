const Koa = require("koa");
const app = new Koa();

app.use(async ctx => {
  console.log(ctx.query);
  ctx.body = ctx.query.number1 + ctx.query.number2;
});

app.listen(3000);
