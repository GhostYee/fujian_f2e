<template>
    <div>
        <input type="number" v-model="number1">
        <input type="number" v-model="number2">
        <div>{{result}}</div>
        <button v-on:click="add()">add</button>
    </div>
</template>
<script>
import { Calculator } from "./Calculator";

export default {
    data() {
        return {
            number1:0,
            number2:0,
            result: 0,
            calculator: new Calculator()
        }
    },
    methods: {
        add() {
            this.result = this.calculator.add(this.number1, this.number2);
        }
    }
}
</script>
