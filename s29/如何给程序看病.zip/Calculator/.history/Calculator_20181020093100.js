class Calculator {
  add(a) {
    return a + b;
  }
}

const calculator = new Calculator();
console.log(calculator.add(1, 2));

export { Calculator };
