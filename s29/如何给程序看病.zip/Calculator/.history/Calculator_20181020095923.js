import { axios } from "axios";

class Calculator {
  addd(a, b) {
    a + b;
  }
}

export { Calculator };
