import axios from "axios";

class Calculator {
  add(number1, number2) {
    fetch(`http://localhost:4000/add?number1=${number1}&number2=${number2}`);
  }
}

export { Calculator };
