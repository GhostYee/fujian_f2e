<template>
    <div>
        <div>{{result}}</div>
        <button v-on:click="add()">add</button>
    </div>
</template>
<script>
import { Calculator } from "./Calculator";

export default {
    data() {
        return {
            result: 0,
            calculator: new Calculator()
        }
    },
    method: {
        add() {
            this.result = this.calculator.add(1, 2);
        }
    }
}
</script>
