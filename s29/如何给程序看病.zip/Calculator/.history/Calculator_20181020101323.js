import axios from "axios";

class Calculator {
  add(number1, number2) {
    fetch("http://localhost:4000/add");
  }
}

export { Calculator };
