<template>
    <div>yo22</div>
</template>
<script>
export default {
    
}
</script>
