class Calculator {
  add(a) {
    return a + b;
  }
}

const calculator = new Calculator();

export { Calculator };
