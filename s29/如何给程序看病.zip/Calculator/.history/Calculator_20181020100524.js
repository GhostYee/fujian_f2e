import axios from "axios";

class Calculator {
  add(number1, number2) {
    axios.get("/add", {
      params: {
        number1,
        number2
      }
    });
  }
}

export { Calculator };
