<template>
    <div>yo</div>
</template>
<script>
export default {
    data() {
        return {
            calculator:new Calculator(): 
        }
    },
    method: {
        add() {
            this.calculator.add(1, 2);
        }
    }
}
</script>
