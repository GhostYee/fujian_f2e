class Calculator {
  add(a, b) {
    return a * b;
  }
  add(a, b, c) {
    return a + b + c;
  }
}

export { Calculator };
