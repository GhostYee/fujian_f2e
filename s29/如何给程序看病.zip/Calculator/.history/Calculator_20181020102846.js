import axios from "axios";

class Calculator {
  add(number1, number2) {
    return axios.get("http://localhost:4000/add", {
      params: { number1, number2 }
    });
  }
  random(min, max) {
    const result = Math.floor(Math.random() * (max - min + 1)) + min;
  }
}

export { Calculator };
