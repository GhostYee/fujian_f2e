<template>
    <div>
        <input type="number" v-model="number1">+
        <input type="number" v-model="number2">
        =
        <span>{{result}}</span>
        <button v-on:click="calculate()">add</button>
    </div>
</template>
<script>
import { Calculator } from "./Calculator";

export default {
    data() {
        return {
            number1:1,
            number2:2,
            result: 0,
            calculator: new Calculator()
        }
    },
    methods: {
        calculate() {
            this.result = this.calculator.add(this.number1, this.number2);
        }
    }
}
</script>
