import { axios } from "axios";

class Calculator {
  addd(number1, number2) {
    axios.get("/add", {
      number1,
      number2
    });
    a + b;
  }
}

export { Calculator };
