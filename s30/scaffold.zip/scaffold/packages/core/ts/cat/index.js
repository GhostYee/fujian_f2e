"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Cat = /** @class */ (function () {
    function Cat() {
    }
    Cat.prototype.cry = function () {
        return "hahh";
    };
    return Cat;
}());
exports.default = Cat;
//# sourceMappingURL=index.js.map