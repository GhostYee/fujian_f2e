export default class Cat {
    cry(): string;
}
