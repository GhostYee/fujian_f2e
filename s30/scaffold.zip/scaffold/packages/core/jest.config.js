const base = require('../../config/jest/base.config');

module.exports = {
  name: '@scaffold/core',
  displayName: '@scaffold/core',
  rootDir: './',

  ...base,
};
