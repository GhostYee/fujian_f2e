export default class Cat {
  public cry() {
    return "hahh";
  }
}
