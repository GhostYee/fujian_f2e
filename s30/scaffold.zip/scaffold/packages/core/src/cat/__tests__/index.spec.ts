import Cat from "../index";

describe("ProfileRepo", () => {
  it("should miao", () => {
    const pussyCat = new Cat();
    expect(pussyCat.cry()).toBe("Miao");
  });
});
