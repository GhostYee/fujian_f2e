import * as React from "react";

import Cat from "@scaffold/core/ts/cat";

import "./index.css";

class App extends React.Component<{}, {}> {
  public render() {
    const cat = new Cat();

    return (
      <div className="App">
        <header className="App-header">
          <p>Hello world!</p>
          <a
            className="App-link"
            href="https://reactjs.org"
            target="_blank"
            rel="noopener noreferrer"
          >
            Learn React, {cat.cry()}
          </a>
        </header>
      </div>
    );
  }
}

export default App;
