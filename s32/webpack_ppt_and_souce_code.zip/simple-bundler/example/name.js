const name = '前端分享/simple-bundler';

export { name };