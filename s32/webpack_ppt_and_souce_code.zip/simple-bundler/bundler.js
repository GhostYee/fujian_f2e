const util = require('util');
const prettier = require('prettier');
const prettyPrintJs = (dist, source) => fs.writeFileSync(dist, prettier.format(source, { parser: 'babel' }));
const inspect = obj =>
  console.log(util.inspect(obj, { colors: true, depth: 5 }));

// ----------
const fs = require('fs');
const path = require('path');
const babylon = require('babylon');
const traverse = require('@babel/traverse').default;
const babel = require('@babel/core');

let ID = 0;
function createModule(filename) {
  const content = fs.readFileSync(filename, 'utf-8');

  const ast = babylon.parse(content, { sourceType: 'module' });

  const dependencies = [];
  traverse(ast, {
    ImportDeclaration: ({ node }) => {
      dependencies.push(node.source.value);
    }
  });

  const { code } = babel.transformFromAstSync(ast, null, {
    presets: ['@babel/preset-env']
  })

  return {
    id: ID++,
    filename,
    dependencies,
    code,
  };
}

// 2. -------------------------
function createGraph(entry) {
  const mainAsset = createModule(entry);
  const modules = [mainAsset];

  for (const module of modules) {
    const dirname = path.dirname(module.filename);
    module.mapping = {};
    module.dependencies.forEach((relativePath) => {
      const dependencyPath = path.join(dirname, relativePath);

      const dependencyModule = createModule(dependencyPath);
      module.mapping[relativePath] = dependencyModule.id;

      modules.push(dependencyModule);
    })
  }

  return modules;
}


// 3. --------------------------------
function bundle(graph) {
  let modules = '';

  graph.forEach((mod) => {
    modules += `${mod.id}: [
      function(require, module, exports) {
        ${mod.code}
      },
      ${JSON.stringify(mod.mapping)}
    ],`;
  })

  const result = `
    (function() {
      const modules = {${modules}};
      function require(id) {
        const [fn, mapping] = modules[id];

        function localRequire(relativePath) {
          return require(mapping[relativePath]);
        }

        const module = { exports: {} };

        fn(localRequire, module, module.exports);

        return module.exports;
      }

      require(0);
    })()
  `;

  return result;
}


const mainBundle = bundle(createGraph('./example/entry.js'));

prettyPrintJs('./dist.js', mainBundle);