// import { app } from 'foundation'

export default {
  namespace: 'page',

  state: {
    name: 'abc'
  },

  subscriptions: {
    setup ({ dispatch, history }) {
      return history.listen(({ pathname, search, params }) => {
        console.log(pathname, search, params)
        // todo
      })
    }
  },

  effects: {
    * init ({ payload }, { put }) {
      // yield put.resolve('')
      yield put('reset')
      yield put('update', { name: 'update' })
    }
  },

  reducers: {
    // update (state, { payload }) {

    // }
  }

}
