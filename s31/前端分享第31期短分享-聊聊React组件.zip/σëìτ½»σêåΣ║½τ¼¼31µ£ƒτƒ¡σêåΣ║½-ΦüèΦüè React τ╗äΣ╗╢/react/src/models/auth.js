import { app } from 'foundation'
import { Toast } from 'antd-mobile'
import { MEMBER, setAuthority } from '../utils/authority'

let countdownHandler

export default {
  namespace: 'auth',

  state: {
    codeBtn: false,
    submitBtn: false,
    countdown: 0,
    mobile: '',
    code: '',
    type: '',
    redirect: null
  },

  subscriptions: {
    setup ({ dispatch, history }) {
      return history.listen(({ pathname, search, params }) => {
        if (pathname === '/auth/login') {
          dispatch('init', params)
        }
      })
    }
  },

  effects: {
    * init ({ payload: { type, redirect } }, { put }) {
      yield put.resolve('cancelCountdown')
      yield put('reset')
      yield put('update', { type, redirect })
    },

    * sendCode ({ payload }, { put, call, isCancelError }) {
      // const isChangMobile = +payload.type === 4
      const delay = ms => new Promise(resolve => setTimeout(resolve, ms))

      function * countdown () {
        try {
          for (let i = 60; i > 0; i--) {
            yield put('update', { countdown: i })
            yield call(delay, 1000)
          }
          yield put('countdown', 0)
        } catch (e) {
          if (!isCancelError(e)) {
            throw e
          }
        }
      }

      try {
        // const { registerType } = app.config.settings
        // yield call(app.apis.sms.verifyCode.doPost, {
        //   ...payload,
        //   type: isChangMobile ? 12 : registerType
        // })
        Toast.info(`验证码已发送，请注意查收`)
        countdownHandler = yield call(countdown)
      } catch (e) {
        app.apis.handleError(e)
      }
    },

    * cancelCountdown (_, { cancel, put }) {
      yield put('countdown', 0)
      if (countdownHandler) {
        yield cancel(countdownHandler)
      }
    },

    * submit ({ payload }, { call, put }) {
      try {
        const boothId = app.context.boothId
        yield call(app.apis.auth.login.doPost, {
          mobile: payload.mobile,
          boothId
        })
        yield put.resolve('success')
      } catch (e) {
        if (e.code === 1091) {
          Toast.info('该账号没有权限登录')
        }
      }
    },

    * success ({ payload }, { put, call, location, select }) {
      Toast.info('登录成功')
      setAuthority(MEMBER)

      const { redirect } = yield select(true)
      if (redirect) {
        yield location.replace(redirect)
      } else {
        let newLocation = app.context.lastLocation
        if (newLocation) {
          let pathname = newLocation.pathname || newLocation
          if (/^\/auth\/?/.test(pathname)) {
            newLocation = null
            const locations = yield select(state => state.common.locations)
            for (let i = locations.length - 2; i >= 0; i--) {
              pathname = locations[i].pathname || locations[i]
              if (!/^\/auth\/?/.test(pathname)) {
                newLocation = locations[i]
                break
              }
            }
          }
        }
        yield location.push(newLocation || '/home')
      }
    }
  },

  reducers: {
    update (state, { payload }) {
      const newState = { ...state, ...payload }
      const isFullMobile = /^\d{11}$/.test(newState.mobile)
      newState.submitBtn = isFullMobile && /^\d{4}$/.test(newState.code)
      newState.codeBtn = isFullMobile && newState.countdown === 0
      return newState
    }
  }

}
