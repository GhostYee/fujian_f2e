import { app } from 'foundation'

export default {
  namespace: 'common',

  state: {
    locations: [],
    lastLocation: null,
    currentLocation: null
  },

  subscriptions: {
    setup ({ dispatch, history }) {
      return history.listen((location) => {
        dispatch('updateLocation', location)
      })
    }
  },

  effects: {
    * updateLocation ({ payload }, { put, select }) {
      const state = yield select(true)
      let newState = { ...state }
      if (newState.currentLocation) {
        newState.lastLocation = newState.currentLocation
        app.context.update({ lastLocation: newState.lastLocation })
      } else if (!newState.lastLocation) {
        newState.lastLocation = app.context.lastLocation
      }
      newState.currentLocation = {
        pathname: payload.pathname,
        hash: payload.hash,
        search: payload.search
      }
      if (newState.locations.length === 0 && newState.lastLocation) {
        newState.locations.push(newState.lastLocation)
      }
      newState.locations.push(newState.currentLocation)
      yield put('update', newState)
    }
  }

}
