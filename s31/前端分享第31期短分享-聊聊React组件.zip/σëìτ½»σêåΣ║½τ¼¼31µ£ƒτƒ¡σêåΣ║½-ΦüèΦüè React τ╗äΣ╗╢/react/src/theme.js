const theme = {

  // 文字色
  'color-text-base': '#333', // 基色
  'color-text-base-inverse': '#fff',

  // 背景色
  'fill-body': '#f5f5f5', // 页面背景色
  'fill-mask': 'rgba(0, 0, 0, 0.5)', // 遮罩背景

  // 全局/品牌色
  'brand-primary': '#ffbc2d',
  'brand-primary-tap': '#cc9624',

  // button
  'button-height': '49 * @hd',
  'button-font-size': '17 * @hd',

  'button-height-sm': '25 * @hd',

  'warning-button-fill': '#ff3c30',
  'ghost-button-fill-tap': '#cc9624'

}
export default theme
