import React from 'react'
import { router } from 'foundation'

const { routerRedux, Route, Switch, AuthorizedRoute, Redirect, getRouterData } = router

const { ConnectedRouter } = routerRedux

function RouterConfig ({ history }) {
  const routerData = getRouterData(model => require(`./models/${model}`))
  const NonAuthed = routerData['~non-authed'].component
  const rootRouter = routerData['~root']
  return (
    <ConnectedRouter history={history}>
      <Switch>
        <Redirect exact from='/' to='/home' />
        <Route path='/auth' component={NonAuthed} />
        <AuthorizedRoute
          path='/'
          component={rootRouter.component}
          authority={rootRouter.authority}
          redirectPath='/auth/login'
        />
      </Switch>
    </ConnectedRouter>
  )
}

export default RouterConfig
