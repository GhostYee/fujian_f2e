/**
 * @author @imruxin
 */
import React, { Component } from 'react'
import PropTypes from 'prop-types'
import styles from './index.scss'

export default class Empty extends Component {
  constructor (props) {
    super(props)
    this.onScroll = this.onScroll.bind(this)
  }

  static propTypes = {
    type: PropTypes.oneOf([
      '404'
    ]).isRequired,
    fixed: PropTypes.bool
  }

  componentDidMount () {
    // window.addEventListener('scroll', this.onScroll, false)
  }

  componentWillUnmount () {
    // window.removeEventListener('scroll', this.onScroll, false)
  }

  onScroll () {
    // todo
  }

  getStyle (type) {
    let style
    switch (type) {
      case '404':
        style = styles['empty-404']
        break
      default:
      // nothing
    }
    return style
  }

  render () {
    const { type, children, fixed } = this.props
    return (
      <div
        className={this.getStyle(type)}
        style={{ position: fixed ? 'fixed' : 'static' }}
      >
        <p>{children}</p>
        <div />
      </div>
    )
  }
}

// optionalArray: PropTypes.array,//检测数组类型
// optionalBool: PropTypes.bool,//检测布尔类型
// optionalFunc: PropTypes.func,//检测函数（Function类型）
// optionalNumber: PropTypes.number,//检测数字
// optionalObject: PropTypes.object,//检测对象
// optionalString: PropTypes.string,//检测字符串
// optionalSymbol: PropTypes.symbol,//ES6新增的symbol类型
