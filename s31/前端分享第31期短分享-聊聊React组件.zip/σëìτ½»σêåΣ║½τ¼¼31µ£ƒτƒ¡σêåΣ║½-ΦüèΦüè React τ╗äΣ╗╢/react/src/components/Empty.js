/**
 * @author @imruxin
 */
import React from 'react'
import PropTypes from 'prop-types'
import styles from '../css/ui.scss'

function getStyle (type) {
  let style
  switch (type) {
    case '404':
      style = styles['empty-404']
      break
    case 'no-data':
      style = styles['empty-no-data']
      break
    default:
    // nothing
  }
  return style
}

const Empty = ({ type, children, fixed }) => {
  return (
    <div
      className={getStyle(type)}
      style={{ position: fixed ? 'fixed' : 'static' }}
    >
      <p>{children}</p>
      <div />
    </div>
  )
}

Empty.propTypes = {
  type: PropTypes.oneOf([
    '404', 'no-data'
  ]).isRequired
}

export default Empty
