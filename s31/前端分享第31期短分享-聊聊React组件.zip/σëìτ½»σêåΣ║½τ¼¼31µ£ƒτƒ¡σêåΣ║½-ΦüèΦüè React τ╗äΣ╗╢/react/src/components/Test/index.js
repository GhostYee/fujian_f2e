/**
* @author @imruxin
*/
import React from 'react'
import PropTypes from 'prop-types'
import styles from './index.scss'

const Test = (props) => {
  return (
    <div className={styles['test-page']}>

    </div>
  )
}

Test.propTypes = {

}

export default Test
