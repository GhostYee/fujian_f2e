/**
* @author @imruxin
*/
import React from 'react'
import PropTypes from 'prop-types'

const Hoc = (WrappedComponent) => {
  // 传入一个组件并返回另一个组件...
  return class Demo extends React.Component {

    constructor(props) {
      super(props)
      this.state = {
        name: ''
      }
      this.handleOnChange = this.handleOnChange.bind(this)
    }

    componentDidMount() {
      console.log('componentDidMount');
    }

    handleOnChange(event) {
      this.setState({
        name: event.target.value
      })
    }
    render() {
      // ... 并使用新数据渲染被包装的组件!
      // 定义需要复合的新属性，是的调用组件的组件具有 name 属性
      const newProps = {
        name: {
          value: this.state.name,
          onChange: this.handleOnChange
        }
      }
      return <WrappedComponent {...this.props} {...newProps}/>;
    }
  };
}

Hoc.propTypes = {
  WrappedComponent: PropTypes.func || PropTypes.object
}

export default Hoc
