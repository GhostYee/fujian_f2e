/**
 * @author @imruxin
 */
import React from 'react'
import createApp, { env } from 'foundation'
import './index.scss'
import config from './config'
import './services/init'
import { Icon } from 'antd-mobile'

// 1. Initialize
const app = createApp({
  config,
  dev: process.env.NODE_ENV !== 'production',
  loadingComponent: (
    <div className='scrim scrim-bg loading-view'>
      <Icon type='loading' />
    </div>
  ),
  onError (error) {
    if (error.isApiError || error.isHttpError) {
      error.preventDefault()
    }
  }
})

/** 2. 安装插件 */
// if (env.wechat) {
//   app.use(require('wechat').createWechat()) // Wechat JSSDK插件
// }
// if (env.alipay) {
//   app.use(require('alipay').createAlipay()) // Alipay JSSDK插件
// }

/** 3. 动态创建models */
// app.model(require('example').default)
app.model(require('./models/common').default)

/** 4. 动态创建路由 */
app.router(require('./router').default)

/** 5. Start */
app.start('#root').then(() => {
  const appLoading = document.getElementById('app-loading')
  appLoading.parentNode.removeChild(appLoading)
})
