/**
 * @author @imruxin
 */
// 需要登录的时候使用 authority: [MEMBER]
// 需要引入什么模块使用 models: ['auth']
// import { MEMBER, GUEST } from '../utils/authority'

export default {
  '/home': {
    name: '首页',
    component: () => require('../pages/Home')
  },

  '/page/func': {
    name: '函数式组件/无状态组件',
    models: ['page'],
    component: () => require('../pages/Func')
  },

  '/page/class': {
    name: '类组件/状态组件',
    models: ['page'],
    // authority: [MEMBER],
    component: () => require('../pages/Class')
  },

  '/page/tpl': {
    name: '模版化组件（TEMPLATE）',
    models: ['page'],
    component: () => require('../pages/Tpl')
  },

  '/page/hoc': {
    name: '高阶组件（抽象逻辑）',
    models: ['page'],
    component: () => require('../pages/Hoc')
  },

  '/page/404': {
    name: 'Empty',
    models: ['page'],
    component: () => require('../pages/NotFound')
  },

  // 公共入口
  '~root': {
    component: () => require('../layouts/BasicLayout')
  },
  '~non-authed': {
    component: () => require('../layouts/NonAuthedLayout')
  }
}
