/**
 * @author @imruxin
 */
import { Toast } from 'antd-mobile'
import { api, log } from 'foundation'
import { GUEST, setAuthority } from '../utils/authority'

api.addEventListener('error', (event) => {
  switch (event.code) {
    case 401:
    case 1090:
    case 1091:
      event.preventDefault()
      setAuthority(GUEST)
      window.location.reload()
      break
    default:
      break
  }
})

api.handleError = (err) => {
  Toast.info(err.message || '请求超时，请刷新重试')
  log.error(err)
}
