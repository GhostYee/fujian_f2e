/**
 * @author @imruxin
 */
import React from 'react'
import { Button, WhiteSpace, WingBlank } from 'antd-mobile'

const Home = ({ history }) => {
  const handleClick = link => event => history.push(link)

  return (
    <WingBlank>
      <WhiteSpace size='lg' />
      <Button onClick={handleClick('/page/func')}>函数组件</Button>
      <WhiteSpace />
      <Button onClick={handleClick('/page/class')}>类组件</Button>
      <WhiteSpace />
      <Button onClick={handleClick('/page/tpl')}>模板组件</Button>
      <WhiteSpace />
      <Button onClick={handleClick('/page/hoc')}>高阶组件</Button>
      <WhiteSpace />
      <Button onClick={handleClick('/page/404')}>open page #404</Button>
      <WhiteSpace />
    </WingBlank>
  )
}

export default Home
