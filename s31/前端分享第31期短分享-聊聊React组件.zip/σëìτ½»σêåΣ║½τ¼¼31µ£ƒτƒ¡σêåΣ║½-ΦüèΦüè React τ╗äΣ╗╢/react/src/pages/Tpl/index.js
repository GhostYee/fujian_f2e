/**
 * @author @imruxin
 */
import React from 'react'
import styles from './index.scss'
import { Empty } from '../../components'

const EmptyType = () => {
  return (
    <div className={styles.page}>
      {/* <Empty type={'404'}>
        <p>服务器开小差了，</p>
        <p>请点击右上角并选择刷新</p>
      </Empty> */}
      <Empty type={'no-data'}>
        <p>sorry~，暂无数据</p>
      </Empty>
    </div>
  )
}

export default EmptyType
