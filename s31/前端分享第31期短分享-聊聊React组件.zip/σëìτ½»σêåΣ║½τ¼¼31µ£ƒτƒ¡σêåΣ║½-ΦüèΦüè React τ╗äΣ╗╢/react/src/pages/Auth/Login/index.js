/**
 * @author @imruxin
 */
import React from 'react'
import { Button, Flex, WhiteSpace, WingBlank } from 'antd-mobile'
import localStyle from './index.scss'

function Login ({ dispatch, auth }) {
  const { submitBtn, type, mobile, code, codeBtn, countdown } = auth

  let inputs = {}
  let codeBtnTitle = countdown <= 0 ? '获取验证码' : `重新获取验证码(${countdown}s)`

  function handleChange (event) {
    let target = event.target
    const { value } = target
    if (!/^\d*$/.test(value)) {
      event.preventDefault()
      return
    }
    switch (target.name) {
      case 'mobile':
        if (value.length <= 11) {
          dispatch('update', { mobile: value })
        }
        break
      case 'code':
        if (value.length <= 4) {
          dispatch('update', { code: value })
        }
        break
      default:
      // nothing
    }
  }

  function handleSendCode () {
    dispatch('sendCode', { mobile, type })
    inputs.code.focus()
  }

  function handleSubmit (event) {
    event.preventDefault()
    dispatch('submit', { mobile })
  }

  function handleInputFocus (event) {
    const el = event.target.parentNode
    switch (event.type) {
      case 'focus':
        el.style.border = '1px solid #ffbd00'
        break
      case 'blur':
        el.style.border = '1px solid #fff'
        break
    }
  }

  return (
    <WingBlank>
      <WhiteSpace size='lg' />
      <Flex key='mobile-row' className={localStyle.mobileRow}>
        <div>
          <input
            name='mobile'
            placeholder='手机号码'
            value={mobile}
            autoFocus
            ref={el => { inputs.mobile = el }}
            type='tel'
            onFocus={handleInputFocus}
            onBlur={handleInputFocus}
            onChange={handleChange}
          />
        </div>
      </Flex>
      <WhiteSpace size='lg' />
      <Flex key='code-row' className={localStyle.verifyRow}>
        <div>
          <input
            name='code'
            placeholder='验证码'
            value={code}
            ref={el => { inputs.code = el }}
            type='tel'
            onFocus={handleInputFocus}
            onBlur={handleInputFocus}
            onChange={handleChange}
          />
        </div>
        <Button onClick={handleSendCode} className={localStyle.verify} disabled={!codeBtn} type='primary' inline>
          {codeBtnTitle}
        </Button>
      </Flex>
      <WhiteSpace />
      <WhiteSpace size='lg' />
      <Button onClick={handleSubmit} className={localStyle.submit} disabled={!submitBtn} type='primary'>
        登录
      </Button>
    </WingBlank>
  )
}

export default Login
