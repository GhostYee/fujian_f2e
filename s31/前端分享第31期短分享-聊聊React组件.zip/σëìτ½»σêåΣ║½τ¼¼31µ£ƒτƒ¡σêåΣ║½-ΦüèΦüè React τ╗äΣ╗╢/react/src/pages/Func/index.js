/**
 * @author @imruxin
 */
import React from 'react'
import { Button, WhiteSpace, WingBlank } from 'antd-mobile'
import { Empty } from '../../components'

const PageOne = (props) => {
  const { history } = props
  const handleHome = () => history.push('/home')
  const handleBack = () => history.goBack()
  return (
    <WingBlank>
      <WhiteSpace size='lg' />
      <Empty type={'404'}>
        <p>服务器开小差了，</p>
        <p>请刷新重试</p>
      </Empty>
      <WhiteSpace />
      <Button onClick={handleBack} type=''>Back</Button>
      <WhiteSpace />
      <Button onClick={handleHome} type=''>Home</Button>
      <WhiteSpace />
    </WingBlank>
  )
}

export default PageOne
