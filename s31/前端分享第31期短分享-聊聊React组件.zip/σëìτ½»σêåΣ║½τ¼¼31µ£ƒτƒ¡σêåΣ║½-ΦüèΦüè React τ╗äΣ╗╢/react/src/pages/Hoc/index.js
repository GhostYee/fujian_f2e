/**
 * @author @imruxin
 */
import React from 'react'
import { Hoc } from '../../components'
import styles from './index.scss'

const HocDemo  = (props) => {

  // props 由自身数据和Hoc数据复合而成
  const { name } = props

  return (
    <div className={styles.page}>
      <div>高阶组件复合示例，请输入内容</div>
      <input className={styles.input} {...props.name}/>
      <div>输入的内容是：{name.value}</div>
    </div>
  )
}

export default Hoc(HocDemo)
