/**
 * @author @imruxin
 */
import React, { Component } from 'react'
import { Button } from 'antd-mobile'
import styles from './index.scss'

class PageTwo extends Component {
  constructor (props) {
    super(props)
    this.state = {
      show: false
    }
    // this.testClick = this.testClick.bind(this)
  }

  testClick = () => {
    this.setState({
      show: !this.state.show
    })
  }

  render () {
    // const { global = {}, dispatch, history } = this.props
    const { show } = this.state
    return (
      <div>
        <div className={styles.page}>类组件</div>
        <div style={{height: "30px", textAlign: 'center'}}>{show && '我是类组件产生的数据'}</div>
        <Button onClick={this.testClick} className={styles.center}>showChange</Button>
      </div>
    )
  }
}

export default PageTwo
