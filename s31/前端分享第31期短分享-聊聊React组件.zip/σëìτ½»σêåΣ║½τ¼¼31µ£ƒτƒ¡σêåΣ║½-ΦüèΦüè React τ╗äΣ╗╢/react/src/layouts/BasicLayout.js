import React from 'react'
import { DocumentTitle, router } from 'foundation'
import NotFound from '../pages/NotFound'

const { Route, RelativeSwitch } = router

const BasicLayout = ({ location, routerData, match }) => {
  const data = routerData[location.pathname]
  const title = (data && data.name) || 'Demo'

  return (
    <DocumentTitle title={title}>
      <RelativeSwitch match={match} redirectPath='/auth/login'>
        <Route component={NotFound} />
      </RelativeSwitch>
    </DocumentTitle>
  )
}

export default BasicLayout
