import React from 'react'
import { router, DocumentTitle } from 'foundation'
import NotFound from '../pages/NotFound'

const { Redirect, RelativeSwitch, Route } = router

const NonAuthedLayout = ({ routerData, location, match }) => {
  const data = routerData[location.pathname]
  const title = (data && data.name) || 'Demo'

  return (
    <DocumentTitle title={title}>
      <RelativeSwitch match={match}>
        <Redirect exact from='/auth' to='/auth/login' />
        <Route render={NotFound} />
      </RelativeSwitch>
    </DocumentTitle>
  )
}

export default NonAuthedLayout
