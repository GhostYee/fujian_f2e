export default {
  // Support type as Object and Array
  // curl -X GET http://localhost:3000/mock/api/users
  'GET /mock/api/users': { users: [1,2] },

  // Method like GET or POST can be omitted
  // '/api/users/1': { id: 1 },

  // Support for custom functions, the API is the same as express@4
  'POST /mock/api/users/create': (req, res) => { res.end('OK'); },
};
