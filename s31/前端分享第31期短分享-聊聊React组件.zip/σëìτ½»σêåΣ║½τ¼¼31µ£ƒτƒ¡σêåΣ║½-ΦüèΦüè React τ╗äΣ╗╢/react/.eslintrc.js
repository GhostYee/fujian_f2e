module.exports = {
  parser: 'babel-eslint',
  extends: [
    'standard',
    'plugin:react/recommended'
  ],
  env: {
    browser: true,
    node: true,
    es6: true
  },
  plugins: [
    'react',
    'jsx-a11y'
  ],
  settings: {
    polyfills: ['fetch', 'promises']
  },
  parserOptions: {
    "ecmaVersion": 6,
    "sourceType": "module",
    'ecmaFeatures': {
      'jsx': true
    }
  },
  rules: {
    'react/display-name': [0, true],
    'react/prop-types': [0],
    'no-unused-vars': [0]
  }
}
