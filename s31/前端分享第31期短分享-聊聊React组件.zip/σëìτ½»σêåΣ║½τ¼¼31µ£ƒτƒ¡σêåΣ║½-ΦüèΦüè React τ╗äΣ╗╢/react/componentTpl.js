/**
 * 组件快速生成脚本,执行命令 npm run cp `文件名`
 */

const fs = require('fs');

const dirName = process.argv[2];

if (!dirName) {
  console.log('文件夹名称不能为空！');
  console.log('示例：npm run cp test');
  process.exit(0);
}

// 页面模版
const indexTep = `/**
* @author @imruxin
*/
import React from 'react'
import PropTypes from 'prop-types'
import styles from './index.scss'

const ${titleCase(dirName)} = (props) => {
  return (
    <div className={styles['${dirName}-page']}>

    </div>
  )
}

${titleCase(dirName)}.propTypes = {

}

export default ${titleCase(dirName)}
`;

// scss文件模版
const scssTep = `.${dirName}-page {

}
`;



fs.mkdirSync(`./src/components/${titleCase(dirName)}`); // mkdir $1
process.chdir(`./src/components/${titleCase(dirName)}`); // cd $1

fs.writeFileSync('index.js', indexTep);
fs.writeFileSync('index.scss', scssTep);

console.log(`组件${titleCase(dirName)}已创建`);

function titleCase(str) {
  const array = str.toLowerCase().split(' ');
  for (let i = 0; i < array.length; i++) {
    array[i] = array[i][0].toUpperCase() + array[i].substring(1, array[i].length);
  }
  const string = array.join(' ');
  return string;
}

process.exit(0);
