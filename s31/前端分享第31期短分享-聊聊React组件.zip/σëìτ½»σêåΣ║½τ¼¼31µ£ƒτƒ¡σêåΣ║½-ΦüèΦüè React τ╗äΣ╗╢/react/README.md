# 说明
--------------------------


- .stylelintrc  => css 检查配置
- .editorconfig => 编辑器配置
- .eslintrc => eslint 配置


使用：

- `yarn`
- `npm start`