// const path = require('path')

export default {
  sass: {},
  define: {
    'process.env.DIST': process.env.DIST,
    'process.env.DIST_ENV': process.env.DIST_ENV
  },
  'entry': 'src/index.js',
  'extraBabelPlugins': [
    ['import', { 'libraryName': 'antd-mobile', 'style': true }]
  ],
  'extraBabelIncludes': ['/node_modules/foundation/'],
  'externals': {
    'react': 'window.React',
    'react-dom': 'window.ReactDOM',
    'foundation': 'foundation',
    'regenerator-runtime': 'regeneratorRuntime',
    'prop-types': 'PropTypes'
  }
}
