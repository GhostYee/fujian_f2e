
import theme from './src/theme'

module.exports = function (webpackConfig, env) {
  /** 遍历loader, 找到lessLoader的include配置替换成以下配置 */
  const extendLessLoader = {
    test: /\.less$/,
    use: [
      'style-loader',
      'css-loader',
      { loader: 'less-loader', options: { modifyVars: theme } }
    ],
    include: /node_modules/
  }
  webpackConfig.module.rules = webpackConfig.module.rules.map((item) => {
    if (new RegExp(item.test).test('.less') && item.include) {
      return extendLessLoader
    }
    return item
  })

  return webpackConfig
}
